document.addEventListener("DOMContentLoaded", function () {
  fetchNews();
  fetchFinance();
  fetchWeather();
});

function closeAd(ad) {
  ad.style.display = "none";
}

function fetchNews() {
  const newsContainer = document.getElementById("news-slider");
  newsContainer.innerHTML = "<h3>Top News</h3><p>(Mock API placeholder)</p>";
}

function fetchFinance() {
  const financeContainer = document.getElementById("finance");
  financeContainer.innerHTML = "<h3>Finance</h3><p>(Mock API placeholder)</p>";
}

function fetchWeather() {
  const weatherContainer = document.getElementById("weather");
  weatherContainer.innerHTML = "<h3>5-Day Weather</h3><p>(Mock API placeholder)</p>";
}